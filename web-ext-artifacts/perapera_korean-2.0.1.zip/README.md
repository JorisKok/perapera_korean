### Debugging

Run with:

`web-ext run --verbose`

`web-ext build`
