### Debugging

Run with:

`web-ext run --verbose`

Build a new version with:

`web-ext build`
