### Debugging

Run with:

`web-ext run --verbose`